import 'react-native-gesture-handler';
import React from 'react';

import App from './src';

export default function Main() {
  return <App />;
}

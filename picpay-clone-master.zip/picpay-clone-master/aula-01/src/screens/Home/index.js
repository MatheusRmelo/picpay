import React from 'react';
import { Text } from 'react-native';

export default function Home() {
  return <Text>Home</Text>;
}